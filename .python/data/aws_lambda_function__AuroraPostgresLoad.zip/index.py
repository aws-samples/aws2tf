import os
import json
import boto3
import cfnresponse
import logging

logging.basicConfig()
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

client = boto3.client('sts')
role_arn = os.environ['auroraroleARN']
response = client.assume_role(RoleArn=role_arn, RoleSessionName='s3import')
aws_access_key_id=response['Credentials']['AccessKeyId']
aws_secret_access_key=response['Credentials']['SecretAccessKey']
aws_session_token=response['Credentials']['SessionToken']

rds_data = boto3.client('rds-data')

def handler(event, context):
     # This comment was added to force an update on this function's code
     logger.info(json.dumps(event))
     if event['RequestType'] != 'Create':
         cfnresponse.send(event, context, cfnresponse.SUCCESS, {'Data': 'NA'})
     else:
       try:
        sql = """
            DROP TABLE IF EXISTS customer_info;
            CREATE TABLE customer_info
            (
            customer_id   BIGINT,
            job_title     VARCHAR(500),
            email_address VARCHAR(100),
            full_name     VARCHAR(200),
            phone_number  VARCHAR(20),
            city          VARCHAR(50),
            state         VARCHAR(50)
            ); 

           create extension if not exists aws_s3 cascade;
           select aws_s3.table_import_from_s3('customer_info', '', '(format csv, header true)', aws_commons.create_s3_uri('redshift-demos', 'ri2023/ant307/data/customer-info/customer_info.csv', 'us-east-1'),
            """
        aws_creds = 'aws_commons.create_aws_credentials(' + "'"+ aws_access_key_id + "'" + ',' + "'" + aws_secret_access_key + "'" + ',' + "'" + aws_session_token + "'" + '));'    
        sql = sql + aws_creds
        response = rds_data.execute_statement(
            resourceArn = os.environ['clusterARN'],
            secretArn = os.environ['clustersecret'],
            database = 'postgres',
            sql = sql
        )
        cfnresponse.send(event, context, cfnresponse.SUCCESS, {'Data': 'Aurora postgres loaded customer_info successfully.'})

       except Exception as e:
                    logger.error(e)
                    cfnresponse.send(event, context, cfnresponse.FAILED, {'Data': 'Aurora Postgres Load Issue - customer_info.'})

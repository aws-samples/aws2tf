import boto3
from datetime import datetime
import calendar
import random
import time
import json
import os
import csv
from time import sleep
from datetime import datetime
import uuid
#from faker import Faker


#faker = Faker()
k_client = boto3.client('kinesis', region_name=os.getenv('region_name'))
stream_name = os.getenv('kinesis_stream')
current_date = datetime.now()
start_range = int(current_date.strftime("%Y%m%d%H%M"))
end_range = start_range +  1000



def handler(event, context):
    
    limit_rows = 1000
    for i in range(limit_rows):
        data = {}
        data['TRANSACTION_ID'] = random.randint(start_range,end_range) #faker.uuid4()
        data['TX_DATETIME'] = datetime.now().isoformat(sep=' ')
        data['CUSTOMER_ID'] = random.randint(1,4999)
        data['TERMINAL_ID'] = random.randint(1,9999)
        data['TX_AMOUNT'] = random.uniform(5, 500)
        data['TX_TIME_SECONDS'] = random.randint(1000,86311)
        data['TX_TIME_DAYS'] = random.randint(0,0)
        
        k_client.put_record(Data=json.dumps(data).encode('utf-8'), StreamName=stream_name,PartitionKey='Demo')

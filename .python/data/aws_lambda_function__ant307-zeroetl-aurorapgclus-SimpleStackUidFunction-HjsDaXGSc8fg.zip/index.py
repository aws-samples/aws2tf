import hashlib
import cfnresponse

def get_md5(account: str, region: str, stack: str, length: int = 8) -> str:
  md5 = hashlib.new('md5')
  md5.update(account.encode('utf-8'))
  md5.update(region.encode('utf-8'))
  md5.update(stack.encode('utf-8'))
  return md5.hexdigest()[:length]

def lambda_handler(event: dict, context) -> None:
  responseData = {}
  if event['RequestType'] == 'Create':
    account = event['ResourceProperties']['AccountId']
    region = event['ResourceProperties']['Region']
    stack = event['StackId']
    md5 = get_md5(account=account, region=region, stack=stack)
    responseData['upper'] = md5.upper()
    responseData['lower'] = md5.lower()
  else: # delete / update
    rs = event['PhysicalResourceId']
    responseData['upper'] = rs.upper()
    responseData['lower'] = rs.lower()
  cfnresponse.send(event, context, cfnresponse.SUCCESS, responseData, responseData['lower'], noEcho=True)
